#!/usr/bin/env python3
# Student ID: [your_seneca_id] (Group Member 4)
"""
Assignment 2: Password Generator with Security Checker Tool
This script integrates the functionalities from our group.
"""

import sys      # For exit function and error codes

# Import functions from our group members' modules
from password_generator import generate_password    # Person 1's module
from password_checker import check_password         # Person 2's module
from argument_parser import parse_arguments         # Person 3's module

def main():
    # Get command line arguments
    args = parse_arguments()    # Get the arguments the user entered
    
    if args.command == "generate":  # Generate password mode
        if args.length < 1:     # Make sure length is valid
            print("Error: password length must be at least 1.")
            sys.exit(1)     # Exit with error code

        pwd = generate_password(args.length)    # Create password

        if args.verbose:    # Show extra info if verbose
            print("Generated password details:")
            print("Allowed characters include letters, digits, and punctuation.")

        print("Generated password:", pwd)   # Show the password

    elif args.command == "check":   # Check password mode
        result = check_password(args.password, verbose=args.verbose)   # Check it
        print(result)   # Show results of the check

if __name__ == "__main__":
    main()  # Run the main function
